module.exports = {
  bot: {
    owners: ["1037732010904526949","582372228709089283","827481339535818753","1112033865645707314"],  // اونر
    botID: "1169749490845098184",    // ايدي البوت
    GuildId: "1148721882980425778",   // ايدي السيرفير
    ClientId: "1169749490845098184",    // ايدي البوت
    serverinvte: "https://discord.com/invite/DPTmayn8gE", // انفايت سير
    clientSECRET: process.env.client , // سكريت
    callbackURL: "https://sp-verfy--afroto123yt.repl.co/login", // الكال باك
    inviteBotUrl: "https://discord.com/api/oauth2/authorize?client_id=1169749490845098184&permissions=1&scope=bot",// انفايت البوت
    TheLinkVerfy : 'https://discord.com/api/oauth2/authorize?client_id=1169749490845098184&redirect_uri=https%3A%2F%2Fsp-verfy--afroto123yt.repl.co%2Flogin&response_type=code&scope=identify%20guilds%20email%20guilds.join', // رابط اوثو رايز بالصلاحيه ادخال الي سيرفرات
    prefix : '#', 
    ceatogry : '1037732010904526949', // كاتوجري الي يفتح فيها تكت شراء
     TOKEN: (process.env.midd),// توكن 
    Price: 850,    // سعر العضو الواحد
    TraId  : '1037732010904526949' // الي يتحوله كريديت
  },
  website: {
    PORT: "3001",
  }
}